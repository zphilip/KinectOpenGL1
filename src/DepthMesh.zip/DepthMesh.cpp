//
// Kinect画像をポリゴンメッシュで表示するサンプル
//
//   OpenNI 付属のサンプル NiSimpleViewer を元にしています
//
//	2011/01/10	Ver.1.0.1	整理
//	2011/01/09	Ver.1.0.0　 初版
//
//	http://twitter.com/kirurobo
//

/*****************************************************************************
*                                                                            *
*  OpenNI 1.0 Alpha                                                          *
*  Copyright (C) 2010 PrimeSense Ltd.                                        *
*                                                                            *
*  This file is part of OpenNI.                                              *
*                                                                            *
*  OpenNI is free software: you can redistribute it and/or modify            *
*  it under the terms of the GNU Lesser General Public License as published  *
*  by the Free Software Foundation, either version 3 of the License, or      *
*  (at your option) any later version.                                       *
*                                                                            *
*  OpenNI is distributed in the hope that it will be useful,                 *
*  but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              *
*  GNU Lesser General Public License for more details.                       *
*                                                                            *
*  You should have received a copy of the GNU Lesser General Public License  *
*  along with OpenNI. If not, see <http://www.gnu.org/licenses/>.            *
*                                                                            *
*****************************************************************************/


//---------------------------------------------------------------------------
// Includes
//---------------------------------------------------------------------------
#include <XnOS.h>
#include <math.h>
#include "gluing.h"

#include <XnCppWrapper.h>

using namespace xn;

//---------------------------------------------------------------------------
// Defines
//---------------------------------------------------------------------------
#define SAMPLE_XML_PATH "..\\Data\\SamplesConfig.xml"
#define MAX_DEPTH 10000

// 画像の横幅（単位はOpenGLにおける長さ）
#define PLANE_SIZE 10.0

// ポリゴンが繋がっていないと判断する閾値（単位はOpenGLにおける長さ）
#define SPLIT_THRESHOLD		0.5

//---------------------------------------------------------------------------
// Globals
//---------------------------------------------------------------------------
float g_pDepthHist[MAX_DEPTH];
XnRGB24Pixel* g_pTexMap = NULL;
unsigned int g_nTexMapX = 0;
unsigned int g_nTexMapY = 0;

Context g_context;
DepthGenerator g_depth;
ImageGenerator g_image;
DepthMetaData g_depthMD;
ImageMetaData g_imageMD;

float* g_pVertices3f = NULL;			// 頂点バッファ
float* g_pNormals3f = NULL;				// 法線バッファ

// ↓分割数。これを小さくすると表示が荒く、大きくすると細かくなる
unsigned int g_nPolyX = 160; //640;		// 横方向の格子数
unsigned int g_nPolyY = 120; //480;		// 縦方向の格子数


//---------------------------------------------------------------------------
// Code
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
// ベクトル・行列演算関数

// ベクトルの長さを返す
float length(const float* vec)
{
	return sqrtf(vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2]);
}

// ベクトルの外積を計算
void cross(const float* vec0, const float* vec1, float* dest)
{
	dest[0] = vec0[1] * vec1[2] - vec0[2] * vec1[1];
	dest[1] = vec0[2] * vec1[0] - vec0[0] * vec1[2];
	dest[2] = vec0[0] * vec1[1] - vec0[1] * vec1[0];
}

// 三角形ポリゴンの法線ベクトルを計算
void normal(const float* vec0, const float* vec1, const float* vec2, float* norm)
{
	float r10[3], r20[3], crs[3];
	for (int i = 0; i < 3; ++i)
	{
		r10[i] = vec0[i] - vec1[i];
		r20[i] = vec0[i] - vec2[i];
	}
	cross(r10, r20, crs);

	float len = length(crs);
	if (len == 0.0) {
		norm[0] = 0;
		norm[1] = 0;
		norm[2] = 1;
	} else {
		norm[0] = crs[0] / len;
		norm[1] = crs[1] / len;
		norm[2] = crs[2] / len;
	}
}


//---------------------------------------------------------------------------
// 初期化処理

// 最初に１回だけ行う処理
//  gluing.h から呼ばれます
bool GLUING_Ready()
{
	// Kinectの準備
	XnStatus rc;

	EnumerationErrors errors;
	rc = g_context.InitFromXmlFile(SAMPLE_XML_PATH, &errors);
	if (rc == XN_STATUS_NO_NODE_PRESENT)
	{
		XnChar strError[1024];
		errors.ToString(strError, 1024);
		printf("%s\n", strError);
		return FALSE;
	}
	else if (rc != XN_STATUS_OK)
	{
		printf("Open failed: %s\n", xnGetStatusString(rc));
		return FALSE;
	}

	rc = g_context.FindExistingNode(XN_NODE_TYPE_DEPTH, g_depth);
	rc = g_context.FindExistingNode(XN_NODE_TYPE_IMAGE, g_image);

	g_depth.GetMetaData(g_depthMD);
	g_image.GetMetaData(g_imageMD);

	// デプスマップをカメラ画像に位置合わせ
	g_depth.GetAlternativeViewPointCap().SetViewPoint(g_image);

	// Hybrid mode isn't supported in this sample
	if (g_imageMD.FullXRes() != g_depthMD.FullXRes() || g_imageMD.FullYRes() != g_depthMD.FullYRes())
	{
		printf ("The device depth and image resolution must be equal!\n");
		return FALSE;
	}

	// RGB is the only image format supported.
	if (g_imageMD.PixelFormat() != XN_PIXEL_FORMAT_RGB24)
	{
		printf("The device image format must be RGB24\n");
		return FALSE;
	}

	// Texture map init
	g_nTexMapX = (((unsigned short)(g_depthMD.FullXRes()-1) / 512) + 1) * 512;
	g_nTexMapY = (((unsigned short)(g_depthMD.FullYRes()-1) / 512) + 1) * 512;
	g_pTexMap = (XnRGB24Pixel*)malloc(g_nTexMapX * g_nTexMapY * sizeof(XnRGB24Pixel));

	// 頂点バッファ確保
	g_pVertices3f = (float*)calloc(g_nPolyX * g_nPolyY * 3, sizeof(float));

	return TRUE;
}


//---------------------------------------------------------------------------
// 描画処理

// OpenGLの描画処理をここに書く。
//   gluing.h から呼ばれます
void GLUING_Draw (void)
{
	XnStatus rc = XN_STATUS_OK;

	// Read a new frame
	rc = g_context.WaitAnyUpdateAll();
	if (rc != XN_STATUS_OK)
	{
		printf("Read failed: %s\n", xnGetStatusString(rc));
		return;
	}

	g_depth.GetMetaData(g_depthMD);
	g_image.GetMetaData(g_imageMD);

	const XnDepthPixel* pDepth = g_depthMD.Data();
	const XnUInt8* pImage = g_imageMD.Data();

	// Calculate the accumulative histogram
	xnOSMemSet(g_pDepthHist, 0, MAX_DEPTH*sizeof(float));

	unsigned int nNumberOfPoints = 0;
	for (XnUInt y = 0; y < g_depthMD.YRes(); ++y)
	{
		for (XnUInt x = 0; x < g_depthMD.XRes(); ++x, ++pDepth)
		{
			if (*pDepth != 0)
			{
				g_pDepthHist[*pDepth]++;
				nNumberOfPoints++;
			}
		}
	}
	for (int nIndex=1; nIndex<MAX_DEPTH; nIndex++)
	{
		g_pDepthHist[nIndex] += g_pDepthHist[nIndex-1];
	}
	if (nNumberOfPoints)
	{
		for (int nIndex=1; nIndex<MAX_DEPTH; nIndex++)
		{
			g_pDepthHist[nIndex] = (unsigned int)(256 * (1.0f - (g_pDepthHist[nIndex] / nNumberOfPoints)));
		}
	}

	xnOSMemSet(g_pTexMap, 0, g_nTexMapX*g_nTexMapY*sizeof(XnRGB24Pixel));

	// check if we need to draw image frame to texture
	const XnRGB24Pixel* pImageRow = g_imageMD.RGB24Data();
	XnRGB24Pixel* pTexRow = g_pTexMap + g_imageMD.YOffset() * g_nTexMapX;

	for (XnUInt y = 0; y < g_imageMD.YRes(); ++y)
	{
		const XnRGB24Pixel* pImage = pImageRow;
		XnRGB24Pixel* pTex = pTexRow + g_imageMD.XOffset();

		for (XnUInt x = 0; x < g_imageMD.XRes(); ++x, ++pImage, ++pTex)
		{
			*pTex = *pImage;
		}

		pImageRow += g_imageMD.XRes();
		pTexRow += g_nTexMapX;
	}

	// 頂点座標初期化
	for (unsigned int y = 0; y < g_nPolyY; ++y)
	{
		for (unsigned int x = 0; x < g_nPolyX; ++x)
		{
			for (int i = 0; i < 3; ++i)
			{
				g_pVertices3f[(y * g_nPolyX + x) * 3 + i] = 0;
			}
		}
	}

	// 対応するポリゴン毎の深度の平均を求める。頂点バッファを一時的に作業領域に使っている
	int px, py;
	const XnDepthPixel* pDepthRow = g_depthMD.Data();
	//XnRGB24Pixel* 
	pTexRow = g_pTexMap + g_depthMD.YOffset() * g_nTexMapX;
	int nXRes = g_depthMD.FullXRes();
	int nYRes = g_depthMD.FullYRes();

	for (XnUInt y = 0; y < nYRes; ++y)
	{
		py = (y + g_depthMD.YOffset()) * g_nPolyY / nYRes;

		const XnDepthPixel* pDepth = pDepthRow;
		XnRGB24Pixel* pTex = pTexRow + g_depthMD.XOffset();

		for (XnUInt x = 0; x < nXRes; ++x, ++pDepth, ++pTex)
		{
			px = (x + g_depthMD.XOffset()) * g_nPolyX / nXRes;

			if (*pDepth != 0)	// 深度0となっている画素は平均値の計算から除く
			{
				int nHistValue = g_pDepthHist[*pDepth];

				// Z値の集計
				g_pVertices3f[(py * g_nPolyX + px) * 3 + 2] +=  (float)nHistValue;	// 頂点ベクトルの第3要素に入れておく（ホントは値が違うけど）

				// 面積の集計
				g_pVertices3f[(py * g_nPolyX + px) * 3] += 1.0;		// 頂点ベクトルの第1要素に入れておく（ホントは用途が違うけど）
			}
		}

		pDepthRow += g_depthMD.XRes();
		pTexRow += g_nTexMapX;
	}

	// 頂点座標を計算
	float dx = (float)PLANE_SIZE / (float)g_nPolyX;
	float dy = (float)PLANE_SIZE * (float)nYRes / (float)nXRes / (float)g_nPolyY;
	float xoffset = -(float)(PLANE_SIZE / 2);
	float yoffset =  (float)(PLANE_SIZE / 2) * (float)nYRes / (float)nXRes;
	float zoffset = -(float)(PLANE_SIZE / 2);
	for (unsigned int y = 0; y < g_nPolyY; ++y)
	{
		for (unsigned int x = 0; x < g_nPolyX; ++x)
		{
			int index = (y * g_nPolyX + x) * 3;

			if (g_pVertices3f[index] > 0.0) {
				// 奥行き計測面積ゼロでなければZ座標を計算
				g_pVertices3f[index + 2] /= (g_pVertices3f[index] * (float)PLANE_SIZE);
			} else {
				// 奥行き計測面積ゼロなら奥行きゼロとする
				g_pVertices3f[index + 2] = 0.0;
			}

			g_pVertices3f[index] = dx * (float)x + xoffset;			// X座標
			g_pVertices3f[index + 1] = dy * -(float)y + yoffset;	// Y座標
			g_pVertices3f[index + 2] = (g_pVertices3f[index + 2] / 5.0) + zoffset;	// Z座標。5.0で割っているのは適当な凹凸に調節するため。
		}
	}

	// Create the OpenGL texture map
	glTexParameteri(GL_TEXTURE_2D, GL_GENERATE_MIPMAP_SGIS, GL_TRUE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, g_nTexMapX, g_nTexMapY, 0, GL_RGB, GL_UNSIGNED_BYTE, g_pTexMap);

	// Display the OpenGL texture map
	glColor4f(1,1,1,1);

	// Enable texture
	glEnable(GL_TEXTURE_2D);

	// 凹凸を付けて描画
	glBegin(GL_TRIANGLES);
	float texWidth = (float)nXRes / (float)g_nTexMapX;
	float texHeight = (float)nYRes / (float)g_nTexMapY;
	for (unsigned int y = 0; y < g_nPolyY - 1; ++y)
	{
		for (unsigned int x = 0; x < g_nPolyX - 1; ++x)
		{
			// 対応するテクスチャの座標
			float tx0 = ((float)x) / (float)(g_nPolyX - 1) * texWidth;
			float ty0 = ((float)y) / (float)(g_nPolyY - 1) * texHeight;
			float tx1 = ((float)x + 1) / (float)(g_nPolyX - 1) * texWidth;
			float ty1 = ((float)y + 1) / (float)(g_nPolyY - 1) * texHeight;

			// ポリゴンの頂点
			float* pUL = g_pVertices3f + ((y * g_nPolyX + x) * 3);
			float* pUR = pUL + 3;
			float* pBR = pUL + (g_nPolyX * 3) + 3;
			float* pBL = pUL + (g_nPolyX * 3);

			// 法線を求める
			float norm[3];

			// 閾値以上離れているメッシュの処理
			if (abs(pUR[2] - pUL[2]) > SPLIT_THRESHOLD || abs(pBR[2] - pBL[2]) > SPLIT_THRESHOLD
				|| abs(pBL[2] - pUL[2]) > SPLIT_THRESHOLD || abs(pBR[2] - pUR[2]) > SPLIT_THRESHOLD) {
// ちょっとトリッキーな書き方だけど、#ifの値で表示方法の選択ができる
// ↓ 1…離れたポリゴンは切り離す，0…切り離さず色を変える
#if 1
					continue;					// 描画しない。つまり隣のポリゴンと切り離す
#else
					glColor3f(0.0, 1.0, 0.0);	// 切り離さず緑にする
			} else {
					glColor3f(1.0, 1.0, 1.0);	// 通常はテクスチャの色になるよう、白とする
#endif
			}

			// 四角形の格子を書くには三角形が２つ要る

			// 三角形その１
			normal(pUL, pUR, pBR, norm);
			glNormal3fv(norm);
			// upper left
			glTexCoord2f(tx0, ty0);
			glVertex3fv(pUL);
			// upper right
			glTexCoord2f(tx1, ty0);
			glVertex3fv(pUR);
			// bottom right
			glTexCoord2f(tx1, ty1);
			glVertex3fv(pBR);

			// 三角形その２
			normal(pBL, pUL, pBR, norm);
			glNormal3fv(norm);
			// bottom left
			glTexCoord2f(tx0, ty1);
			glVertex3fv(pBL);
			// upper right
			glTexCoord2f(tx0, ty0);
			glVertex3fv(pUL);
			// bottom right
			glTexCoord2f(tx1, ty1);
			glVertex3fv(pBR);
		}
	}

	glEnd();
}

