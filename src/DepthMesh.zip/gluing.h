// OpenGL (with GLUT & GLUI) を学習するためのライブラリ
// 
//   GLUING - GLUI wo Nantonaku Gakushu surutameno library.
// 
//
// OpenGL で簡単な GUI が扱える GLUI を使って図形を描きます。
//   GLUI …  http://glui.sourceforge.net/
// 
// GLUTやOpenGLについては以下のサイトなどが参考になります
// http://www.wakayama-u.ac.jp/~tokoi/opengl/libglut.html
// http://www.komoto.org/opengl/sample01.html
//
//
// 使い方
//   当ファイルをincludeして、以下の2つの関数を実装してください。
// --------------------------------------------------------------------------
//   #include "gluing.h"
//   bool GLUING_Ready() { return true; /* 初期化(失敗時はfalseで終了) */ }
//   void GLUING_Draw()  { /* 描画処理 */ }
// --------------------------------------------------------------------------
//
// GLUING_Draw() 中でアニメーション等に使うための
// 時刻[sec]を表す変数 GLUING_TIME を利用できます。
//
//
// Ver. 1.2.0	2009/04/23	glColorが反映されるように修正＆座標軸表示
// Ver. 1.1.0	2009/04/22	アニメーションの時刻を実時間に変更
// Ver. 1.0.0	2009/04/21	初版

#ifdef _WIN32
#include <windows.h>
#pragma comment(lib, "glut32.lib")
#ifdef _DEBUG
#	pragma comment(lib, "glui32d.lib")
#else
#	pragma comment(lib, "glui32.lib")
#endif
#endif

#include <math.h>
#include <GL/glui.h>


// Constants.
#define PI		3.14159265358979	// 円周率
#define CTRLID_ANI_START		1	// アニメーション開始ボタンの識別番号
#define CTRLID_ANI_STOP			2	// アニメーション終了ボタンの識別番号
#define CTRLID_CAMERA_RESET		0	// カメラコントロールを初期値に戻す

// Global variables.
int gMainWindowID = NULL;	// 描画ウィンドウのID（gluiで使用します）
float gTime     = 0.0;		// 時刻 t (秒)
float gTimeMax  = 10.0;		// 時刻 t の最大値(秒)
float gTimeMin  = 0.0;		// 時刻 t の最小値(秒)
int   gShowAxes = 0;		// 座標軸を表示させる場合は 1
float gRotateMat[16] = { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };	// カメラ回転行列
float gPanVec[]      = { 0.0, 0.0, 0.0 };						// カメラ平行移動量
GLUI *goGlui;
GLUI_Rotation    *goCamRotation;
GLUI_Translation *goCamTransrationXY;
GLUI_Translation *goCamTransrationZ;
int gStartElapsedTime = 0;		// アニメーション開始時のGLUT_ELAPSED_TIMEを保持する変数
int gLoopFlag	= 1;

double GLUING_TIME = 0.0;		// アニメーション開始からの経過時刻[sec]


// Function prototypes.
void initGL();
void initGLUI();
void glutReshape(int, int);
void glutDisplay();
void glutIdle();
void glutMenu(int);
void controlCallback(int);
void drawGraphics();
void resetElapsedTime();
void startAnimation();
void stopAnimation();
int getTime();

void GLUING_Draw();
bool GLUING_Ready();


// Main routine
int main(int argc, char *argv[])
{
    glutInitWindowSize(1000, 600);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    glutInit(&argc, argv);

	if (!GLUING_Ready()) {
		return 1;
	}

    gMainWindowID = glutCreateWindow("OpenGL");

    // Set glut callback functions.
	GLUI_Master.set_glutDisplayFunc(glutDisplay);
	GLUI_Master.set_glutReshapeFunc(glutReshape);
	GLUI_Master.set_glutIdleFunc(glutIdle);

    initGL();
	initGLUI();

    glutMainLoop();

    return 0;
}

// Draw
void drawGraphics(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// アニメーション用現在時刻代入
	GLUING_TIME = (double)gTime;

	// アプリの描画ルーチン呼び出し
	GLUING_Draw();

	// 座標軸の描画
	if (gShowAxes) {
		glPushAttrib(GL_ALL_ATTRIB_BITS);
		glDisable(GL_LIGHTING);
		glDisable(GL_NORMALIZE);
		glDisable(GL_COLOR_MATERIAL);
		glDisable(GL_TEXTURE_2D);

		glBegin(GL_LINES);
		// X軸
		glColor3f(1.0, 0.0, 0.0);
		glVertex3d(0.0, 0.0, 0.0);
		glVertex3d(1.0, 0.0, 0.0);

		// Y軸
		glColor3f(0.0, 1.0, 0.0);
		glVertex3d(0.0, 0.0, 0.0);
		glVertex3d(0.0, 1.0, 0.0);

		// Z軸
		glColor3f(0.0, 0.0, 1.0);
		glVertex3d(0.0, 0.0, 0.0);
		glVertex3d(0.0, 0.0, 1.0);
		glEnd();
		glPopAttrib();
	}
	glColor3f(1.0, 1.0, 1.0);
}

// Set up general OpenGL rendering properties: lights, depth buffering, etc.
void initGL()
{
	// Lighting
    static const GLfloat light_model_ambient[] = {0.3f, 0.3f, 0.3f, 1.0f};

    static const GLfloat light0_diffuse[] = {0.9f, 0.9f, 0.9f, 0.9f};
    //static const GLfloat light0_direction[] = {-0.2f, -0.4f, 0.5f, 0.0f};
    static const GLfloat light0_direction[] = {0.408f, 0.408f, -0.816f, 0.0f};

    static const GLfloat light1_diffuse[] = {0.1f, 0.1f, 0.1f, 0.1f};
    //static const GLfloat light1_direction[] = {-0.2f, 0.4f, 0.2f, 0.0f};
    static const GLfloat light1_direction[] = {0.0f, 0.0f, -1.0f, 0.0f};
    
    // Enable depth buffering for hidden surface removal.
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_DEPTH_TEST);
    
    // Setup other misc features.
    glEnable(GL_LIGHTING);
    glEnable(GL_NORMALIZE);
    glShadeModel(GL_SMOOTH);

	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    
    // Setup lighting model.
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_FALSE);
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, light_model_ambient);

    glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light0_direction);
    glEnable(GL_LIGHT0);

    glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse);
    glLightfv(GL_LIGHT1, GL_POSITION, light1_direction);
    glEnable(GL_LIGHT1);

	// Background color
	glClearColor(0.3, 0.5, 0.7, 1.0);
}

// Initializes GLUI user interface.
void initGLUI()
{
    goGlui = GLUI_Master.create_glui_subwindow(gMainWindowID, GLUI_SUBWINDOW_RIGHT);
    
    // Camera control.
    GLUI_Panel *camctrl_panel = goGlui->add_rollout("Camera control", true);

	// Add 'Show axes' checkbox.
	GLUI_Checkbox *axescheckbox = goGlui->add_checkbox_to_panel(camctrl_panel, "Show axes", &gShowAxes);
	axescheckbox->set_alignment(GLUI_ALIGN_CENTER);

    goCamRotation = goGlui->add_rotation_to_panel(
        camctrl_panel, "Rotate View", gRotateMat);
    goCamRotation->set_spin( 1.0 );
    
    goCamTransrationXY = goGlui->add_translation_to_panel(
        camctrl_panel, "Pan", GLUI_TRANSLATION_XY, gPanVec);
    //goCamTransrationXY->set_speed( 0.01 );
    
    goCamTransrationZ = goGlui->add_translation_to_panel(
        camctrl_panel, "Zoom", GLUI_TRANSLATION_Z, &gPanVec[2]);
    //goCamTransrationZ->set_speed( 0.01 );

	// Add 'Reset' button.
	goGlui->add_button_to_panel(camctrl_panel, "Reset", CTRLID_CAMERA_RESET, controlCallback);

	// Time span.
    GLUI_Panel *time_panel = goGlui->add_rollout("Animation", true);
	GLUI_Spinner *timemin_spinner = goGlui->add_spinner_to_panel(time_panel, "Start [sec]", GLUI_SPINNER_FLOAT, &gTimeMin);
	timemin_spinner->set_float_limits(-100.0, 100.0);
	timemin_spinner->set_alignment(GLUI_ALIGN_RIGHT);

	GLUI_Spinner *timemax_spinner = goGlui->add_spinner_to_panel(time_panel, "End [sec]", GLUI_SPINNER_FLOAT, &gTimeMax);
	timemax_spinner->set_float_limits(-100.0, 100.0);
	timemax_spinner->set_alignment(GLUI_ALIGN_RIGHT);

	//GLUI_Spinner *timestep_spinner = goGlui->add_spinner_to_panel(time_panel, "Step", GLUI_SPINNER_FLOAT, &gTimeStep);
	//timestep_spinner->set_float_limits(0.001, 10.0);
	//timestep_spinner->set_alignment(GLUI_ALIGN_RIGHT);

	GLUI_Checkbox *loop_checkbox = goGlui->add_checkbox_to_panel(time_panel, "Loop", &gLoopFlag);
	loop_checkbox->set_alignment(GLUI_ALIGN_CENTER);

	// Add 'Animation Start/Stop' button.
	goGlui->add_separator_to_panel(time_panel);
	goGlui->add_button_to_panel(time_panel, "Start animation", CTRLID_ANI_START, controlCallback);
	goGlui->add_button_to_panel(time_panel, "Stop animation", CTRLID_ANI_STOP, controlCallback);

	// Add 'Quit' button.
    goGlui->add_button("Quit", 0, (GLUI_Update_CB) exit);
    
    goGlui->set_main_gfx_window(gMainWindowID);
}

// Callback function for UI.
//
// Parameter
//	control : Identifier
void controlCallback(int control)
{
	switch (control) {
		case CTRLID_CAMERA_RESET:	// カメラ操作のリセットボタンが押された
			goCamRotation->reset();
			goCamTransrationXY->set_x(0.0);
			goCamTransrationXY->set_y(0.0);
			goCamTransrationZ->set_z(0.0);
			break;
		case CTRLID_ANI_START:	// アニメーション開始ボタンが押された
			startAnimation();
			break;
		case CTRLID_ANI_STOP:	// アニメーション停止ボタンが押された
			stopAnimation();
			break;
	}
}

// GLUT callback for reshaping the window.
// This is the main place where the viewing and workspace transforms get initialized.
//
// Pamareters
//	width	: Window width
//	height	: Window height
void glutReshape(int width, int height)
{
	static const double kFovY = 40;
	int tx, ty;
    double nearDist, farDist, aspect;

	GLUI_Master.get_viewport_area(&tx, &ty, &width, &height);
    glViewport(tx, ty, width, height);

    // Compute the viewing parameters based on a fixed fov and viewing
    // a canonical box centered at the origin.
    nearDist = 1.0 / tan((kFovY / 2.0) * PI / 180.0);
    farDist = nearDist + 100.0;
    aspect = (double) width / height;
   
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(kFovY, aspect, nearDist, farDist);

    // Place the camera down the Z axis looking at the origin.
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();            
    gluLookAt(0, 0, nearDist + 5.0,
              0, 0, 0,
              0, 1, 0);
}

// GLUT callback for redrawing the view.
void glutDisplay()
{
	glPushMatrix();
	glTranslatef(gPanVec[0] / 50.0, gPanVec[1] / 50.0, -gPanVec[2] / 10.0);		// Is "trans->set_spped()" not working?
	glMultMatrixf(gRotateMat);

    drawGraphics();			// Draw shapes.

	glPopMatrix();

    glutSwapBuffers();		// Change drawing buffer.
}

// GLUT callback for idling.
//  ここでアニメーションの制御を行う
void glutIdle()
{
	// おまじない
	if (glutGetWindow() != gMainWindowID) {
		glutSetWindow(gMainWindowID);
	}
    glutPostRedisplay();

	// 指定時刻を過ぎたか検証
	int time = getTime();
	gTime = (double)(time - gStartElapsedTime) / 1000.0;
	if (gTime > gTimeMax) {
		if (gLoopFlag) {
			// ループONなら時刻をリセット
			resetElapsedTime();
		} else {
			// ループOFFならアニメーション終了とする
			stopAnimation();
		}
	}
}

// 経過時間をリセット
void resetElapsedTime()
{
	gStartElapsedTime = getTime() - (int)(gTimeMin * 1000.0);
	gTime = gTimeMin;
}

// アニメーションを開始させる
void startAnimation()
{
	resetElapsedTime();
	GLUI_Master.set_glutIdleFunc(glutIdle);
}

// アニメーションを終了させる
void stopAnimation()
{
	GLUI_Master.set_glutIdleFunc(NULL);
}

/// 開始してからの時間を返す
int getTime()
{
#ifdef _WIN32
	static int begin_time = 0;
	int now_time;

	SYSTEMTIME time_val;
	GetLocalTime(&time_val);

	// "日"単位以上の長期にわたる動作は考慮していない
	now_time
		= time_val.wHour * 3600000
		+ time_val.wMinute * 60000
		+ time_val.wSecond *  1000
		+ time_val.wMilliseconds;
	if (!begin_time) {
		begin_time = now_time;
	} else if (begin_time > now_time) {
		begin_time = begin_time - 86400000;		// 日付をまたいで動かしたときの対応
	}
	return now_time - begin_time;
#else
	return glutGet(GLUT_ELAPSED_TIME);
#endif
}